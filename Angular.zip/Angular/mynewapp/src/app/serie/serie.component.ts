import { Component, OnInit } from '@angular/core';
import { Serie } from './serie';
import { SerieService } from './serie.service';

@Component({
  selector: 'app-serie',
  templateUrl: './serie.component.html',
  styleUrls: ['./serie.component.css'],
})
export class SerieComponent implements OnInit {
  series: Array<Serie> = [];
  constructor(private serieService: SerieService) {}

  public pro: number = 0;

  getSeries() : void{
    this.serieService.getSeries().subscribe((series) => {
      this.series = series;
      this.getPro();
    });
  }

  getPro() {
    for (let i of this.series) {
      this.pro += i.seasons;
    }

    this.pro = this.pro / this.series.length;
  }

  ngOnInit() {
    this.getSeries();

  }
}
